<template>
  <section class="projects">
    <h2>Проекты</h2>
  </section>
</template>