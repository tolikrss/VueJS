<template>
  <section class="brands">
    <h2>Бренды</h2>
  </section>
</template>