<template>
  <section class="contacts">
    <h2>Контакты</h2>
  </section>
</template>