module.exports = [
  {
    title: 'Sit modi quod assumenda non blanditiis sint',
    body: 'Ipsum sequi est officia nobis. Excepturi sit earum amet ea et. Et ea laboriosam placeat asperiores cupiditate asperiores ea suscipit. Est qui officia quaerat earum. Adipisci rem voluptatem quia totam perferendis illo laudantium mollitia. Corporis quisquam dignissimos a alias eum. Distinctio quisquam corporis veritatis dolorem consequatur consequuntur et id. Autem vitae qui eum voluptas. Error omnis nulla omnis quos asperiores eum.',
    image: 'https://images.unsplash.com/photo-1415663058438-995397760614?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=ee7fb8668a89cb9955e2d9c939abb161'
  },
  {
    title: 'Et dignissimos id temporibus nemo consectetur quis',
    body: 'Nemo eum odit velit recusandae accusantium dicta Qui minima ipsam qui ut Eos molestiae itaque ipsam a sint ratione Vitae est hic iure ut deserunt Numquam in quia et dolorem Alias doloribus cumque esse asperiores. Hic odio non aut maxime. Nobis ipsum at voluptas aut Enim soluta at tempore Consectetur quis commodi commodi minus sit.',
    image: 'https://images.unsplash.com/photo-1455073245179-4f017a6e0ea8?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=8d448a08f23fe922f7c673afe1bafef0'
  },
  {
    title: 'Fuga molestiae nesciunt dolorem quia',
    body: 'Nobis sint minus molestiae. iste et fuga accusamus Tenetur deserunt delectus ipsum qui consequatur dolor Ratione corporis minus quo placeat Qui ipsam ipsam voluptatibus aliquid odit id. Deleniti aut fugiat suscipit. Nostrum inventore quae est eos voluptatem. Tenetur ipsum et pariatur tempore Iusto labore at molestias Natus quis at dolorem.',
    image: 'https://images.unsplash.com/photo-1444530495635-029990f82ce8?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=4465988ca798e116375c231a002cc049'
  },
  {
    title: 'Quam et sit omnis modi',
    body: 'Sit et corrupti dignissimos molestiae non nostrum vero. Sit quidem excepturi qui inventore blanditiis et amet. Odio qui aut tempore qui dolore quibusdam Cupiditate dolores pariatur vel nobis sed dolor ipsum. Hic et sapiente ut. dolor voluptates. Commodi et odio nam excepturi est enim. Nulla amet similique ea ducimus quidem Cumque dolores est dolor eaque.',
    image: 'https://images.unsplash.com/photo-1456318019777-ccdc4d5b2396?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=b40778785fd7e862476f1a515ab2b93c'
  },
  {
    title: 'Iste dolor est soluta',
    body: 'Assumenda qui dolorem quia sit hic ea qui. Dolorum esse ut sunt ut eveniet quis dignissimos. Cumque nihil quae ut Temporibus debitis et est Tenetur eos Nihil eos voluptas aliquam amet pariatur. impedit nisi Beatae nesciunt omnis qui velit veniam aut. Est illo soluta ratione. et mollitia. Voluptas vero voluptatum reiciendis aut est.',
    image: 'https://images.unsplash.com/46/unsplash_52c319226cefb_1.JPG?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=a810597ec34553d86299930c2b1b24b7'
  }
]
